/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
#define MPU6050_ADDR             (0x68 << 1)
#define MPU6050_REG_WHO_AM_I     0x75
#define MPU6050_REG_PWR_MGMT1    0x6B
#define MPU6050_REG_ACCEL_XOUT_H 0x3B
#define MPU6050_REG_ACCEL_CONFIG 0x1C

#define MPU6050_REG_GYRO_CONFIG  0x1B
static bool mpu_ok = false;

static uint32_t debug_sim_count = 0;
static uint32_t debug_led_refresh_count = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
static bool MPU6050_Init(void);
static void BuildLedPositions(void);
static void FluidSetup(void);
static void FluidSimStepXY(float gx, float gy);
static void UpdateForces_FromMPU(float dt, float *out_gx, float *out_gy);
static void UpdateLedFramebuffer(void);
static void LedRefresh_ScanOnce(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
static void Debug_Print(const char *msg) {
HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100);
}

static void Debug_PrintInt(const char *label, int32_t val) {
char buf[64];
snprintf(buf, sizeof(buf), "%s: %ld\r\n", label, val);
Debug_Print(buf);
}

static void Debug_PrintFloat(const char *label, float val) {
char buf[64];
int whole = (int)val;
int frac = (int)((val - whole) * 1000);
if (frac < 0) frac = -frac;
snprintf(buf, sizeof(buf), "%s: %d.%03d\r\n", label, whole, frac);
Debug_Print(buf);
}

static HAL_StatusTypeDef MPU6050_ReadReg(uint8_t reg, uint8_t *data) {
    return HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, reg, I2C_MEMADD_SIZE_8BIT, data, 1, 100);
}

static HAL_StatusTypeDef MPU6050_WriteReg(uint8_t reg, uint8_t value) {
    return HAL_I2C_Mem_Write(&hi2c1, MPU6050_ADDR, reg, I2C_MEMADD_SIZE_8BIT, &value, 1, 100);
}

static bool MPU6050_Init(void) {
    Debug_Print("MPU6050: Init...\r\n");

    uint8_t who = 0;
    if (MPU6050_ReadReg(MPU6050_REG_WHO_AM_I, &who) != HAL_OK) {
        Debug_Print("MPU6050: I2C read failed\r\n");
        return false;
    }

    Debug_PrintInt("WHO_AM_I", who);

    if (who != 0x68 && who != 0x70) {
        Debug_Print("MPU6050: Wrong device ID\r\n");
        return false;
    }

    if (MPU6050_WriteReg(MPU6050_REG_PWR_MGMT1, 0x00) != HAL_OK) {
        Debug_Print("MPU6050: Wake failed\r\n");
        return false;
    }
    HAL_Delay(10);

    if (MPU6050_WriteReg(MPU6050_REG_ACCEL_CONFIG, 0x00) != HAL_OK) {
        Debug_Print("MPU6050: Config failed\r\n");
        return false;
    }

    if (MPU6050_WriteReg(MPU6050_REG_GYRO_CONFIG, 0x00) != HAL_OK) {
        Debug_Print("MPU6050: Gyro config failed\r\n\"");
        return false;
    }
    Debug_Print("MPU6050: OK\r\n");
    return true;
}
/*  Charlieplex */
typedef struct {
    GPIO_TypeDef *port;
    uint16_t      pin;
} CharliePin;

#define NUM_PINS 16
static const CharliePin cPins[NUM_PINS] = {
    {GPIOA, GPIO_PIN_0},  // 0: PA0
    {GPIOA, GPIO_PIN_1},  // 1: PA1
    {GPIOA, GPIO_PIN_3},  // 3: PA3
    {GPIOA, GPIO_PIN_4},  // 4: PA4
    {GPIOA, GPIO_PIN_5},  // 5: PA5
    {GPIOA, GPIO_PIN_6},  // 6: PA6
    {GPIOA, GPIO_PIN_7},  // 7: PA7
    {GPIOA, GPIO_PIN_8},  // 8: PA8
    {GPIOA, GPIO_PIN_9},  // 9: PA9
    {GPIOA, GPIO_PIN_10}, // 10: PA10
    {GPIOA, GPIO_PIN_11}, // 11: PA11
    {GPIOB, GPIO_PIN_5},  // 12: PB5
    {GPIOB, GPIO_PIN_4},  // 13: PB4
	{GPIOB, GPIO_PIN_0},  // 14: PB0
    {GPIOB, GPIO_PIN_1},  // 15: PB1
};

typedef struct { uint8_t hi, lo; } LedPair;


static const LedPair ledMap[] = {
    {10, 3}, // LED4: між PA4 (hi) та PA2 (lo)
    {3, 10}, // LED5: між PA2 (hi) та PA4 (lo)
    {8, 10}, // LED6: між PA6 (hi) та PA4 (lo)
    {10, 8}, // LED7: між PB4 (hi) та PA6 (lo)
    {8, 6}, // LED8: між PA8 (hi) та PA6 (lo)
    {6, 8}, // LED9: між PA6 (hi) та PA8 (lo)
    {4, 6}, // LED10: між PA10 (hi) та PA8 (lo)
    {6, 4}, // LED11: між PA8 (hi) та PA10 (lo)
    {5, 4}, // LED12: між PA12 (hi) та PA10 (lo)
    {4, 5}, // LED13: між PA10 (hi) та PA12 (lo)

    {10, 1}, // LED19: між PA4 (hi) та PA0 (lo)
    {1, 10}, // LED20: між PA0 (hi) та PA4 (lo)
    {8, 3}, // LED21: між PA6 (hi) та PA2 (lo)
    {3, 8}, // LED22: між PA2 (hi) та PA6 (lo)
    {6, 10}, // LED23: між PA8 (hi) та PA4 (lo)
    {10, 6}, // LED24: між PA4 (hi) та PA8 (lo)
    {4, 8}, // LED25: між PA10 (hi) та PA6 (lo)
    {8, 4}, // LED26: між PA6 (hi) та PA10 (lo)
    {5, 6}, // LED27: між PA12 (hi) та PA8 (lo)
    {6, 5}, // LED28: між PA8 (hi) та PA12 (lo)
    {11, 4}, // LED29: між PA14 (hi) та PA10 (lo)
    {4, 11}, // LED30: між PA10 (hi) та PA14 (lo)

    {10, 0}, // LED34: між PA4 (hi) та PA1 (lo)
    {0, 10}, // LED35: між PA1 (hi) та PA4 (lo)
    {8, 1}, // LED36: між PA6 (hi) та PA0 (lo)
    {1, 8}, // LED37: між PA0 (hi) та PA6 (lo)
    {6, 3}, // LED38: між PA8 (hi) та PA2 (lo)
    {3, 6}, // LED39: між PA2 (hi) та PA8 (lo)
    {4, 10}, // LED40: між PA10 (hi) та PA4 (lo)
    {10, 4}, // LED41: між PA4 (hi) та PA10 (lo)
    {5, 8}, // LED42: між PA12 (hi) та PA6 (lo)
    {8, 5}, // LED43: між PA6 (hi) та PA12 (lo)
    {11, 6}, // LED44: між PA14 (hi) та PA8 (lo)
    {6, 11}, // LED45: між PA8 (hi) та PA14 (lo)
    {7, 4}, // LED46: між PA15 (hi) та PA10 (lo)
    {4, 7}, // LED47: між PA10 (hi) та PA15 (lo)

    {10, 2}, // LED49: між PA4 (hi) та PA3 (lo)
    {2, 10}, // LED50: між PA3 (hi) та PA4 (lo)
    {8, 0}, // LED51: між PA6 (hi) та PA1 (lo)
    {0, 8}, // LED52: між PA1 (hi) та PA6 (lo)
    {6, 1}, // LED53: між PA8 (hi) та PA0 (lo)
    {1, 6}, // LED54: між PA0 (hi) та PA8 (lo)
    {4, 3}, // LED55: між PA10 (hi) та PA2 (lo)
    {3, 4}, // LED56: між PA2 (hi) та PA10 (lo)
    {5, 10}, // LED57: між PA12 (hi) та PA4 (lo)
    {10, 5}, // LED58: між PA4 (hi) та PA12 (lo)
    {11, 8}, // LED59: між PA14 (hi) та PA6 (lo)
    {8, 11}, // LED60: між PA6 (hi) та PA14 (lo)
    {7, 6}, // LED61: між PA15 (hi) та PA8 (lo)
    {6, 7}, // LED62: між PA8 (hi) та PA15 (lo)
    {9, 4}, // LED63: між PA13 (hi) та PA10 (lo)
    {4, 9}, // LED64: між P10 (hi) та PA13 (lo)

    {12, 10}, // LED65: між PA5 (hi) та PA4 (lo)
    {8, 2}, // LED66: між PA6 (hi) та PA3 (lo)
    {2, 8}, // LED67: між PA3 (hi) та PA6 (lo)
    {6, 0}, // LED68: між PA8 (hi) та PA1 (lo)
    {0, 1}, // LED69: між PA1 (hi) та PA8 (lo)
    {1, 0}, // LED70: між PA10 (hi) та PA0 (lo)
    {0, 4}, // LED71: між PA0 (hi) та PA10 (lo)
    {5, 3}, // LED72: між PA12 (hi) та PA2 (lo)
    {3, 5}, // LED73: між PA2 (hi) та PA12 (lo)
    {11, 10}, // LED74: між PA14 (hi) та PA4 (lo)
    {10, 11}, // LED75: між PA4 (hi) та PA14 (lo)
    {7, 8}, // LED76: між PA15 (hi) та PA6 (lo)
    {8, 7}, // LED77: між PA6 (hi) та PA15 (lo)
    {9, 6}, // LED78: між PA13 (hi) та PA8 (lo)
    {6, 9}, // LED79: між PA8 (hi) та PA13 (lo)
    {4, 11}, // LED80: між PA10 (hi) та PA11 (lo)

    {8, 12}, // LED81: між PA6 (hi) та PA5 (lo)
    {12, 8}, // LED82: між PA5 (hi) та PA6 (lo)
    {6, 2}, // LED83: між PA8 (hi) та PA3 (lo)
    {2, 6}, // LED84: між PA3 (hi) та PA8 (lo)
    {4, 0}, // LED85: між PA10 (hi) та PA1 (lo)
    {0, 4}, // LED86: між PA1 (hi) та PA10 (lo)
    {5, 1}, // LED87: між PA12 (hi) та PA0 (lo)
    {1, 5}, // LED88: між PA0 (hi) та PA12 (lo)
    {11, 3}, // LED89: між PA14 (hi) та PA2 (lo)
    {3, 11}, // LED90: між PA2 (hi) та PA14 (lo)
    {7, 10}, // LED91: між PA15 (hi) та PA4 (lo)
    {10, 7}, // LED92: між PA4 (hi) та PA15 (lo)
    {9, 8}, // LED93: між PA13 (hi) та PA6 (lo)
    {8, 9}, // LED94: між PA6 (hi) та PA13 (lo)
    {14, 6}, // LED95: між PA11 (hi) та PA8 (lo)
    {6, 14}, // LED96: між PA8 (hi) та PA11 (lo)

    {15, 8}, // LED97: між PA7 (hi) та PA6 (lo)
    {6, 12}, // LED98: між PA8 (hi) та PA5 (lo)
    {12, 6}, // LED99: між PA5 (hi) та PA8 (lo)
    {4, 2}, // LED100: між P10 (hi) та PA3 (lo)
    {2, 4}, // LED101: між PA3 (hi) та PA10 (lo)
    {5, 0}, // LED102: між PA12 (hi) та PA1 (lo)
    {0, 5}, // LED103: між PA1 (hi) та PA12 (lo)
    {11, 1}, // LED104: між PA14 (hi) та PA0 (lo)
    {1, 11}, // LED105: між PA0 (hi) та PA14 (lo)
    {7, 3}, // LED106: між PA15 (hi) та PA2 (lo)
    {3, 7}, // LED107: між PA2 (hi) та PA15 (lo)
    {9, 10}, // LED108: між PA13 (hi) та PA4 (lo)
    {10, 9}, // LED109: між PA4 (hi) та PA13 (lo)
    {14, 8}, // LED110: між PA11 (hi) та PA6 (lo)
    {8, 14}, // LED111: між PA6 (hi) та PA11 (lo)
    {6, 13}, // LED112: між PA8 (hi) та PA9 (lo)

    {6, 15}, // LED113: між PA8 (hi) та PA7 (lo)
    {15, 6}, // LED114: між PA7 (hi) та PA8 (lo)
    {4, 12}, // LED115: між PA10 (hi) та PA5 (lo)
    {12, 4}, // LED116: між PA5 (hi) та PA10 (lo)
    {5, 2}, // LED117: між PA12 (hi) та PA3 (lo)
    {2, 5}, // LED118: між PA3 (hi) та PA12 (lo)
    {11, 0}, // LED119: між PA14 (hi) та PA1 (lo)
    {0, 11}, // LED120: між PA1 (hi) та PA14 (lo)
    {7, 1}, // LED121: між PA15 (hi) та PA0 (lo)
    {1, 7}, // LED122: між PA0 (hi) та PA15 (lo)
    {9, 3}, // LED123: між PA13 (hi) та PA2 (lo)
    {3, 9}, // LED124: між PA2 (hi) та PA13 (lo)
    {14, 10}, // LED125: між PA11 (hi) та PA4 (lo)
    {10, 14}, // LED126: між PA4 (hi) та PA11 (lo)
    {13, 8}, // LED127: між PA9 (hi) та PA6 (lo)
    {8, 13}, // LED128: між PA6 (hi) та PA9 (lo)

    {13, 6}, // LED129: між PA9 (hi) та PA8 (lo)
    {4, 15}, // LED130: між PA10 (hi) та PA7 (lo)
    {15, 4}, // LED131: між PA7 (hi) та PA10 (lo)
    {5, 12}, // LED132: між PA12 (hi) та PA5 (lo)
    {12, 5}, // LED133: між PA5 (hi) та PA12 (lo)
    {11, 2}, // LED134: між PA14 (hi) та PA3 (lo)
    {2, 11}, // LED135: між PA3 (hi) та PA14 (lo)
    {7, 0}, // LED136: між PA15 (hi) та PA1 (lo)
    {0, 7}, // LED137: між PA1 (hi) та PA15 (lo)
    {9, 1}, // LED138: між PA13 (hi) та PA0 (lo)
    {1, 9}, // LED139: між PA0 (hi) та PA13 (lo)
    {14, 3}, // LED140: між PA11 (hi) та PA2 (lo)
    {3, 14}, // LED141: між PA2 (hi) та PA11 (lo)
    {13, 10}, // LED142: між PA9 (hi) та PA4 (lo)
    {10, 13}, // LED143: між PA4 (hi) та PA9 (lo)
    {8, 15}, // LED144: між PA6 (hi) та PA7 (lo)

    {4, 13}, // LED145: між PA10 (hi) та PA9 (lo)
    {13, 4}, // LED146: між PA9 (hi) та PA10 (lo)
    {5, 15}, // LED147: між PA12 (hi) та PA7 (lo)
    {15, 5}, // LED148: між PA7 (hi) та PA12 (lo)
    {11, 12}, // LED149: між PA14 (hi) та PA5 (lo)
    {12, 11}, // LED150: між PA5 (hi) та PA14 (lo)
    {7, 2}, // LED151: між PA15 (hi) та PA3 (lo)
    {2, 7}, // LED152: між PA3 (hi) та PA15 (lo)
    {9, 0}, // LED153: між PA13 (hi) та PA1 (lo)
    {0, 9}, // LED154: між PA1 (hi) та PA13 (lo)
    {14, 1}, // LED155: між PA11 (hi) та PA0 (lo)
    {1, 14}, // LED156: між PA0 (hi) та PA11 (lo)
    {15, 3}, // LED157: між PA7 (hi) та PA2 (lo)
    {3, 15}, // LED158: між PA2 (hi) та PA7 (lo)
    {15, 10}, // LED159: між PA7 (hi) та PA4 (lo)
    {10, 15}, // LED160: між PA4 (hi) та PA7 (lo)

    {14, 4}, // LED161: між PA11 (hi) та PA10 (lo)
    {5, 13}, // LED162: між PA12 (hi) та PA9 (lo)
    {13, 5}, // LED163: між PA9 (hi) та PA12 (lo)
    {11, 15}, // LED164: між PA14 (hi) та PA7 (lo)
    {15, 11}, // LED165: між PA7 (hi) та PA14 (lo)
    {7, 12}, // LED166: між PA15 (hi) та PA5 (lo)
    {12, 7}, // LED167: між PA5 (hi) та PA15 (lo)
    {9, 2}, // LED168: між PA13 (hi) та PA3 (lo)
    {2, 9}, // LED169: між PA3 (hi) та PA13 (lo)
    {14, 0}, // LED170: між PA11 (hi) та PA1 (lo)
    {0, 14}, // LED171: між PA1 (hi) та PA11 (lo)
    {13, 1}, // LED172: між PA9 (hi) та PA0 (lo)
    {1, 13}, // LED173: між PA0 (hi) та PA9 (lo)
    {15, 3}, // LED174: між PA7 (hi) та PA2 (lo)
    {3, 15}, // LED175: між PA2 (hi) та PA7 (lo)
    {10, 12}, // LED176: між PA4 (hi) та PA5 (lo)

    {5, 14}, // LED177: між PA12 (hi) та PA11 (lo)
    {14, 5}, // LED178: між PA11 (hi) та PA12 (lo)
    {11, 13}, // LED179: між PA14 (hi) та PA9 (lo)
    {13, 11}, // LED180: між PA9 (hi) та PA14 (lo)
    {7, 15}, // LED181: між PA15 (hi) та PA7 (lo)
    {15, 7}, // LED182: між PA7 (hi) та PA15 (lo)
    {9, 12}, // LED183: між PA13 (hi) та PA5 (lo)
    {12, 9}, // LED184: між PA5 (hi) та PA13 (lo)
    {14, 2}, // LED185: між PA11 (hi) та PA3 (lo)
    {2, 14}, // LED186: між PA3 (hi) та PA11 (lo)
    {13, 0}, // LED187: між PA9 (hi) та PA1 (lo)
    {0, 13}, // LED188: між PA1 (hi) та PA9 (lo)
    {15, 1}, // LED189: між PA7 (hi) та PA0 (lo)
    {1, 15}, // LED190: між PA0 (hi) та PA7 (lo)
    {12, 3}, // LED191: між PA5 (hi) та PA2 (lo)
    {3, 12}, // LED192: між PA2 (hi) та PA5 (lo)

    {11, 14}, // LED194: між PA14 (hi) та PA11 (lo)
    {14, 11}, // LED195: між PA11 (hi) та PA14 (lo)
    {7, 13}, // LED196: між PA15 (hi) та PA9 (lo)
    {13, 7}, // LED197: між PA9 (hi) та PA15 (lo)
    {9, 15}, // LED198: між PA13 (hi) та PA7 (lo)
    {15, 9}, // LED199: між PA7 (hi) та PA13 (lo)
    {14, 12}, // LED200: між PA11 (hi) та PA5 (lo)
    {12, 14}, // LED201: між PA5 (hi) та PA11 (lo)
    {13, 2}, // LED202: між PA9 (hi) та PA3 (lo)
    {2, 13}, // LED203: між PA3 (hi) та PA9 (lo)
    {15, 0}, // LED204: між PA7 (hi) та PA1 (lo)
    {0, 15}, // LED205: між PA1 (hi) та PA7 (lo)
    {12, 1}, // LED206: між PA5 (hi) та PA0 (lo)
    {1, 12}, // LED207: між PA0 (hi) та PA5 (lo)

    {7, 14}, // LED211: між PA15 (hi) та PA11 (lo)
    {14, 7}, // LED212: між PA11 (hi) та PA15 (lo)
    {9, 13}, // LED213: між PA13 (hi) та PA9 (lo)
    {13, 9}, // LED214: між PA9 (hi) та PA13 (lo)
    {14, 15}, // LED215: між PA11 (hi) та PA7 (lo)
    {15, 14}, // LED216: між PA7 (hi) та PA11 (lo)
    {13, 12}, // LED217: між PA9 (hi) та PA5 (lo)
    {12, 13}, // LED218: між PA5 (hi) та PA9 (lo)
    {15, 2}, // LED219: між PA7 (hi) та PA3 (lo)
    {2, 15}, // LED220: між PA3 (hi) та PA7 (lo)
    {12, 0}, // LED221: між PA5 (hi) та PA1 (lo)
    {0, 12}, // LED222: між PA1 (hi) та PA5 (lo)

    {9, 14}, // LED228: між PA13 (hi) та PA11 (lo)
    {14, 9}, // LED229: між PA11 (hi) та PA13 (lo)
    {14, 13}, // LED230: між PA11 (hi) та PA9 (lo)
    {13, 14}, // LED231: між PA9 (hi) та PA11 (lo)
    {1, 13}, // LED232: між PA0 (hi) та PA9 (lo)
    {13, 1}, // LED233: між PA9 (hi) та PA0 (lo)
    {15, 12}, // LED234: між PA7 (hi) та PA5 (lo)
    {12, 15}, // LED235: між PA5 (hi) та PA7 (lo)
    {12, 2}, // LED236: між PA5 (hi) та PA3 (lo)
    {2, 12}, // LED237: між PA3 (hi) та PA5 (lo)

};

#define LED_COUNT ((uint16_t)(sizeof(ledMap) / sizeof(ledMap[0])))
#define LED_ROWS 16
#define LED_COLS 15

static void SetPinMode(uint8_t idx, uint32_t mode) {
    if (idx >= NUM_PINS) return;
    GPIO_InitTypeDef cfg = {0};
    cfg.Pin = cPins[idx].pin;
    cfg.Mode = mode;
    cfg.Pull = GPIO_NOPULL;
    cfg.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(cPins[idx].port, &cfg);
}

static void AllPinsHiZ(void) {
    for (uint8_t i = 0; i < NUM_PINS; i++) {
        HAL_GPIO_WritePin(cPins[i].port, cPins[i].pin, GPIO_PIN_RESET);
        SetPinMode(i, GPIO_MODE_INPUT);
    }
}

static inline void LedOn(uint16_t idx) {
    if (idx >= LED_COUNT) return;

    uint8_t hi = ledMap[idx].hi;
    uint8_t lo = ledMap[idx].lo;

    if (hi >= NUM_PINS || lo >= NUM_PINS || hi == lo) return;

    AllPinsHiZ();

    SetPinMode(hi, GPIO_MODE_OUTPUT_PP);
    HAL_GPIO_WritePin(cPins[hi].port, cPins[hi].pin, GPIO_PIN_SET);

    SetPinMode(lo, GPIO_MODE_OUTPUT_PP);
    HAL_GPIO_WritePin(cPins[lo].port, cPins[lo].pin, GPIO_PIN_RESET);
}

//  LED POSITION MAPPING
// Map rectangular matrix to circular display coordinates
static float ledX[LED_COUNT];
static float ledY[LED_COUNT];

static void BuildLedPositions(void) {

    for (uint16_t i = 0; i < LED_COUNT && i < LED_ROWS * LED_COLS; i++) {
        int row = i / LED_COLS;
        int col = i % LED_COLS;

        float x = (float)col / (float)(LED_COLS - 1);
        float y = (float)row / (float)(LED_ROWS - 1);

        // Center around 0.5
        x = x * 0.9f + 0.05f;
        y = y * 0.9f + 0.05f;

        ledX[i] = x;
        ledY[i] = y;
    }

    Debug_PrintInt("LEDs mapped", LED_COUNT);
}

// FLUID SIMULATION
static inline float clampf(float x, float a, float b) {
    if (x < a) return a;
    if (x > b) return b;
    return x;
}

#define RES 20
#define FNUMX (RES + 1)
#define FNUMY (RES + 1)
#define FCELLS (FNUMX * FNUMY)
#define MAXP 300

enum { FLUID_CELL = 0, AIR_CELL = 1, SOLID_CELL = 2 };

typedef struct {
    float density;
    int fNumX, fNumY;
    float h, invH;

    float particleDensity[FCELLS];
    uint8_t cellType[FCELLS];
    float s[FCELLS];

    int numParticles;
    float particlePos[2 * MAXP];
    float particleVel[2 * MAXP];
    float particleRestDensity;
    float particleRadius;
} FlipFluid;

static FlipFluid fluid;

static void IntegrateParticles(float dt, float gx, float gy) {
    for (int i = 0; i < fluid.numParticles; i++) {
        fluid.particleVel[2*i+0] += dt * gx;
        fluid.particleVel[2*i+1] += dt * gy;
        fluid.particlePos[2*i+0] += fluid.particleVel[2*i+0] * dt;
        fluid.particlePos[2*i+1] += fluid.particleVel[2*i+1] * dt;
    }
}

static void HandleParticleCollisions(void) {
    float h = fluid.h;
    float r = fluid.particleRadius;
    float centerX = (fluid.fNumX * h) * 0.5f;
    float centerY = (fluid.fNumY * h) * 0.5f;
    float circleR = fminf(centerX, centerY) - h * 1.5f;

    for (int i = 0; i < fluid.numParticles; i++) {
        float x = fluid.particlePos[2*i+0];
        float y = fluid.particlePos[2*i+1];

        float dx = x - centerX;
        float dy = y - centerY;
        float dist = sqrtf(dx*dx + dy*dy);

        if (dist > (circleR - r)) {
            float ang = atan2f(dy, dx);
            x = centerX + cosf(ang) * (circleR - r);
            y = centerY + sinf(ang) * (circleR - r);

            float nx = cosf(ang);
            float ny = sinf(ang);
            float vn = fluid.particleVel[2*i+0]*nx + fluid.particleVel[2*i+1]*ny;
            fluid.particleVel[2*i+0] -= 1.5f * vn * nx;
            fluid.particleVel[2*i+1] -= 1.5f * vn * ny;
        }

        fluid.particlePos[2*i+0] = x;
        fluid.particlePos[2*i+1] = y;
    }
}

static void UpdateParticleDensity(void) {
    int n = fluid.fNumY;
    float h = fluid.h;
    float invH = fluid.invH;
    float h2 = 0.5f * h;

    for (int i = 0; i < FCELLS; i++) {
        fluid.particleDensity[i] = 0.0f;
        fluid.cellType[i] = (fluid.s[i] == 0.0f) ? SOLID_CELL : AIR_CELL;
    }

    for (int i = 0; i < fluid.numParticles; i++) {
        float x = clampf(fluid.particlePos[2*i+0], h, (fluid.fNumX - 1) * h);
        float y = clampf(fluid.particlePos[2*i+1], h, (fluid.fNumY - 1) * h);

        int xi = (int)clampf(floorf(x * invH), 0, fluid.fNumX - 1);
        int yi = (int)clampf(floorf(y * invH), 0, fluid.fNumY - 1);
        int cell = xi*n + yi;

        if (fluid.cellType[cell] == AIR_CELL) {
            fluid.cellType[cell] = FLUID_CELL;
        }

        int x0 = (int)floorf((x - h2) * invH);
        float tx = ((x - h2) - (float)x0 * h) * invH;
        int x1 = x0 + 1;
        if (x0 < 0) x0 = 0;
        if (x1 > fluid.fNumX - 1) x1 = fluid.fNumX - 1;

        int y0 = (int)floorf((y - h2) * invH);
        float ty = ((y - h2) - (float)y0 * h) * invH;
        int y1 = y0 + 1;
        if (y0 < 0) y0 = 0;
        if (y1 > fluid.fNumY - 1) y1 = fluid.fNumY - 1;

        float sx = 1.0f - tx;
        float sy = 1.0f - ty;

        fluid.particleDensity[x0*n + y0] += sx * sy;
        fluid.particleDensity[x1*n + y0] += tx * sy;
        fluid.particleDensity[x1*n + y1] += tx * ty;
        fluid.particleDensity[x0*n + y1] += sx * ty;
    }

    if (fluid.particleRestDensity == 0.0f) {
        float sum = 0.0f;
        int cnt = 0;
        for (int i = 0; i < FCELLS; i++) {
            if (fluid.cellType[i] == FLUID_CELL) {
                sum += fluid.particleDensity[i];
                cnt++;
            }
        }
        if (cnt > 0) {
            fluid.particleRestDensity = sum / (float)cnt;
        }
    }
}

static void FluidSimStepXY(float gx, float gy) {
    const float DT = 1.0f / 60.0f;

    IntegrateParticles(DT, gx, gy);
    HandleParticleCollisions();
    UpdateParticleDensity();

    debug_sim_count++;
}

static void FluidSetup(void) {
    Debug_Print("Fluid: Setup...\r\n");

    const float SIM_W = 3.0f;
    const float SIM_H = 3.0f;

    fluid.density = 1000.0f;
    fluid.fNumX = FNUMX;
    fluid.fNumY = FNUMY;
    fluid.h = SIM_H / (float)RES;
    fluid.invH = 1.0f / fluid.h;

    float h = fluid.h;
    float r = 0.3f * h;
    float dx = 2.0f * r;
    float dy = 0.86602540378f * dx;
    fluid.particleRadius = r;

    float relWaterH = 0.6f, relWaterW = 0.6f;

    int numX = (int)floorf((relWaterW*SIM_W - 2.0f*h - 2.0f*r) / dx);
    int numY = (int)floorf((relWaterH*SIM_H - 2.0f*h - 2.0f*r) / dy);

    int maxP = numX * numY;
    if (maxP > MAXP) maxP = MAXP;

    fluid.numParticles = maxP;
    fluid.particleRestDensity = 0.0f;

    int p = 0;
    for (int i = 0; i < numX && (p/2) < maxP; i++) {
        for (int j = 0; j < numY && (p/2) < maxP; j++) {
            fluid.particlePos[p++] = h + r + dx*(float)i + ((j % 2) ? r : 0.0f);
            fluid.particlePos[p++] = h + r + dy*(float)j;
        }
    }

    for (int i = 0; i < 2*fluid.numParticles; i++) {
        fluid.particleVel[i] = 0.0f;
    }

    int n = fluid.fNumY;
    float cx = (float)fluid.fNumX * 0.5f;
    float cy = (float)fluid.fNumY * 0.5f;
    float maxDist = fminf(cx, cy) - 1.0f;

    for (int i = 0; i < fluid.fNumX; i++) {
        for (int j = 0; j < fluid.fNumY; j++) {
            float dxg = (float)i - cx;
            float dyg = (float)j - cy;
            float dist = sqrtf(dxg*dxg + dyg*dyg);
            fluid.s[i*n + j] = (dist < maxDist) ? 1.0f : 0.0f;
        }
    }

    Debug_PrintInt("Particles", fluid.numParticles);
    Debug_Print("Fluid: OK\r\n");
}

//  LED FRAMEBUFFER ї
static uint8_t ledFB[LED_COUNT];

#define LED_DENS_MIN 0.012f
#define LED_DENS_REL 0.28f
#define LED_SPREAD_ON  1

static void UpdateLedFramebuffer(void) {
    const float SIM_W = 3.0f;
    const float SIM_H = 3.0f;
    int n = fluid.fNumY;
    float h = fluid.h;

    // take dens on every LED and max dens in cadr
    static float densLed[LED_COUNT];
    float maxDens = 0.0f;

    for (uint16_t i = 0; i < LED_COUNT; i++) {
        float sx = ledX[i] * SIM_W;
        float sy = ledY[i] * SIM_H;

        int xi = (int)clampf(floorf(sx / h), 0, fluid.fNumX - 1);
        int yi = (int)clampf(floorf(sy / h), 0, fluid.fNumY - 1);
        int cell = xi*n + yi;

        float dens = fluid.particleDensity[cell];
        uint8_t isFluid = (fluid.cellType[cell] == FLUID_CELL);

        densLed[i] = isFluid ? dens : 0.0f;
        if (densLed[i] > maxDens) maxDens = densLed[i];
    }

    float thr = LED_DENS_MIN;
    float rel = LED_DENS_REL * maxDens;
    if (rel > thr) thr = rel;
    for (uint16_t i = 0; i < LED_COUNT; i++) {
        ledFB[i] = (densLed[i] > thr) ? 1 : 0;
    }

#if LED_SPREAD_ON
    static uint8_t tmp[LED_COUNT];
    for (uint16_t i = 0; i < LED_COUNT; i++) tmp[i] = ledFB[i];

    for (uint16_t i = 0; i < LED_COUNT; i++) {
        if (!tmp[i]) continue;

        int r = i / LED_COLS;
        int c = i % LED_COLS;

        if (c > 0)           ledFB[i - 1] = 1;
        if (c < LED_COLS-1)  ledFB[i + 1] = 1;
        if (r > 0)           ledFB[i - LED_COLS] = 1;
        if (r < LED_ROWS-1)  ledFB[i + LED_COLS] = 1;
    }
#endif
}

static void LedRefresh_ScanOnce(void) {
    for (uint16_t i = 0; i < LED_COUNT; i++) {
        if (!ledFB[i]) continue;

        LedOn(i);

        // Timing: adjust for brightness (200-1000 range)
        for (volatile int d = 0; d < 600; d++) {
            __NOP();
        }
    }
    AllPinsHiZ();
    debug_led_refresh_count++;
}

//  MPU - 6050
static float rot = 0.0f;          // tilt angle proxy (for debug)
static float yaw = 0.0f;          // integrated spin angle (horizontal mode)
static float prev_omega_z = 0.0f; // rad/s

static void UpdateForces_FromMPU(float dt, float *out_gx, float *out_gy) {
    // Reads 14 bytes starting at 0x3B: AX, AY, AZ, TEMP, GX, GY, GZ
    uint8_t raw[14];

    if (HAL_I2C_Mem_Read(&hi2c1, MPU6050_ADDR, MPU6050_REG_ACCEL_XOUT_H,
                        I2C_MEMADD_SIZE_8BIT, raw, 14, 50) != HAL_OK) {
        mpu_ok = false;
        *out_gx = 0.0f;
        *out_gy = 0.0f;
        return;
    }

    int16_t ax = (int16_t)((raw[0]  << 8) | raw[1]);
    int16_t ay = (int16_t)((raw[2]  << 8) | raw[3]);
    int16_t az = (int16_t)((raw[4]  << 8) | raw[5]);
    int16_t gz = (int16_t)((raw[12] << 8) | raw[13]);

    const float A_SENS = 16384.0f; // LSB/g
    const float G_SENS = 131.0f;   // LSB/(deg/s)

    float faz = (float)az / A_SENS;

    float omega_z = ((float)gz / G_SENS) * (float)M_PI / 180.0f; // rad/s

    // --- decide mode ---
    // Horizontal hold: |az| near 1g
    bool horizontal = (fabsf(faz) > 0.80f);

    const float GRAV = 9.81f;

    if (!horizontal) {
        // Tilt-driven flow
        float a = atan2f((float)ax, (float)ay);

        const float alpha = 0.15f;
        rot = (1.0f - alpha) * rot + alpha * a;

        *out_gx = GRAV * sinf(rot);
        *out_gy = GRAV * cosf(rot);

        // reset spin integrator to avoid drift when not in horizontal mode
        yaw = 0.0f;
        prev_omega_z = omega_z;
        return;
    }

    // Horizontal mode: simulate "sloshing" from spin / angular acceleration
    yaw += omega_z * dt;

    float alpha_z = (omega_z - prev_omega_z) / dt; // rad/s^2
    prev_omega_z = omega_z;

    // Artistic gain: increase if effect is too weak
    const float K_ALPHA = 0.25f;
    float a = K_ALPHA * alpha_z; // pseudo-accel in m/s^2 (tuned)

    *out_gx = a * cosf(yaw);
    *out_gy = a * sinf(yaw);

    // Provide a meaningful debug "rot" even in horizontal mode:
    rot = 0.0f;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  BuildLedPositions();
  FluidSetup();

  AllPinsHiZ();

  Debug_Print("=== Init Complete ===\r\n");
  Debug_PrintInt("Total LEDs", LED_COUNT);


  // Initialize MPU6050
  mpu_ok = MPU6050_Init();
  // Test pattern
  Debug_Print("LED test...\r\n");
  for (uint16_t i = 0; i < LED_COUNT; i++) {
      ledFB[i] = 1;
  }
  for (int t = 0; t < 50; t++) {
      LedRefresh_ScanOnce();
      HAL_Delay(10);
  }


  // Clear after test
  for (uint16_t i = 0; i < LED_COUNT; i++) {
      ledFB[i] = 0;
  }
  Debug_Print("Main loop start\r\n");
  /* USER CODE END 2 */

  uint32_t lastSimMs = 0;
  uint32_t lastDebugMs = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  LedRefresh_ScanOnce();

	  uint32_t now = HAL_GetTick();

      if ((now - lastSimMs) >= 16) {
          lastSimMs = now;

          float gx = 0.0f, gy = 0.0f;

          if (mpu_ok) {
              UpdateForces_FromMPU(1.0f/60.0f, &gx, &gy);
          } else {
              // Try re-init once per second
              static uint32_t lastTryMs = 0;
              if ((now - lastTryMs) >= 1000u) {
                  lastTryMs = now;
                  mpu_ok = MPU6050_Init();
              }
          }

          FluidSimStepXY(gx, gy);
          UpdateLedFramebuffer();
}

      if ((now - lastDebugMs) >= 2000) {
          lastDebugMs = now;

          Debug_Print("=== Status ===\r\n");
          Debug_PrintInt("Sim", debug_sim_count);
          Debug_PrintInt("Refresh", debug_led_refresh_count);
          Debug_PrintFloat("Rot", rot);
          Debug_PrintInt("MPU", mpu_ok ? 1 : 0);

          int lit = 0;
          for (int i = 0; i < LED_COUNT; i++) {
              if (ledFB[i]) lit++;
          }
          Debug_PrintInt("Lit", lit);
          Debug_Print("\r\n");
      }

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00B07CB4;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pins : PA0 PA1 PA3 PA4
                           PA5 PA6 PA7 PA8
                           PA9 PA10 PA11 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB3 PB4
                           PB5 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
